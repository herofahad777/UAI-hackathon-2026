import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, Contact } from '@/types';

const INITIAL_ACCOUNTS: User[] = [
  {
    id: 'user-1',
    name: 'Arjun Mehta',
    phone: '9876543210',
    upiId: 'arjun@securepay',
    balance: 124750.50,
    trustScore: 100,
    isSuspended: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'user-2',
    name: 'Priya Patel',
    phone: '9123456789',
    upiId: 'priya@upi',
    balance: 45000.00,
    trustScore: 100,
    isSuspended: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'user-3',
    name: 'Rahul Sharma',
    phone: '9876000000',
    upiId: 'rahul@okicici',
    balance: 500.00,
    trustScore: 40,
    isSuspended: true,
    suspendedAt: new Date(Date.now() - 86400000).toISOString(),
    createdAt: new Date().toISOString(),
  }
];

export interface Appeal {
  id: string;
  userId: string;
  name: string;
  reason: string;
  details: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

interface UserState {
  accounts: User[];
  contacts: Contact[];
  appeals: Appeal[];
  setBalance: (userId: string, amount: number) => void;
  deductBalance: (userId: string, amount: number) => void;
  addBalance: (userId: string, amount: number) => void;
  suspendAccount: (userId: string) => void;
  reinstateAccount: (userId: string) => void;
  updateTrustScore: (userId: string, score: number) => void;
  addAppeal: (appeal: Omit<Appeal, 'id' | 'status' | 'createdAt'>) => void;
  resolveAppeal: (appealId: string, status: 'approved' | 'rejected') => void;
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      accounts: INITIAL_ACCOUNTS,
      contacts: [],
      appeals: [],

      setBalance: (userId, amount) =>
        set((state) => ({
          accounts: state.accounts.map(a => a.id === userId ? { ...a, balance: amount } : a)
        })),

      deductBalance: (userId, amount) =>
        set((state) => ({
          accounts: state.accounts.map(a => a.id === userId ? { ...a, balance: Math.max(0, a.balance - amount) } : a)
        })),

      addBalance: (userId, amount) =>
        set((state) => ({
          accounts: state.accounts.map(a => a.id === userId ? { ...a, balance: a.balance + amount } : a)
        })),

      suspendAccount: (userId) =>
        set((state) => ({
          accounts: state.accounts.map(a => a.id === userId ? { ...a, isSuspended: true, suspendedAt: new Date().toISOString() } : a)
        })),

      reinstateAccount: (userId) =>
        set((state) => ({
          accounts: state.accounts.map(a => a.id === userId ? { ...a, isSuspended: false, suspendedAt: undefined, trustScore: 100 } : a)
        })),

      updateTrustScore: (userId, score) =>
        set((state) => ({
          accounts: state.accounts.map(a => a.id === userId ? { ...a, trustScore: Math.max(0, Math.min(100, score)) } : a)
        })),

      addAppeal: (appeal) =>
        set((state) => ({
          appeals: [...state.appeals, { ...appeal, id: `app-${Date.now()}`, status: 'pending', createdAt: new Date().toISOString() }]
        })),
        
      resolveAppeal: (appealId, status) =>
        set((state) => ({
          appeals: state.appeals.map(a => a.id === appealId ? { ...a, status } : a)
        }))
    }),
    { name: 'securepay-users' }
  )
);

// Listen for cross-tab updates
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === 'securepay-users') {
      useUserStore.persist.rehydrate();
    }
  });
}
