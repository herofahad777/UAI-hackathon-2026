import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Transaction } from '@/types';

interface TransactionState {
  transactions: Transaction[];
  addTransaction: (tx: Transaction) => void;
  getRecentTransactions: (userId: string, minutes: number) => Transaction[];
  filterTransactions: (userId: string, opts: { startDate?: string; endDate?: string; minAmount?: number; maxAmount?: number }) => Transaction[];
  getUserTransactions: (userId: string) => Transaction[];
  clearAll: () => void;
}

export const useTransactionStore = create<TransactionState>()(
  persist(
    (set, get) => ({
      transactions: [],

      addTransaction: (tx) =>
        set((state) => ({ transactions: [tx, ...state.transactions] })),

      getUserTransactions: (userId) => {
        return get().transactions.filter(t => t.fromUserId === userId || t.toUserId === userId);
      },

      getRecentTransactions: (userId, minutes) => {
        const cutoff = Date.now() - minutes * 60 * 1000;
        return get().getUserTransactions(userId).filter(
          (tx) => new Date(tx.timestamp).getTime() > cutoff && tx.status === 'success' && tx.fromUserId === userId
        );
      },

      filterTransactions: (userId, { startDate, endDate, minAmount, maxAmount }) => {
        return get().getUserTransactions(userId).filter((tx) => {
          const ts = new Date(tx.timestamp).getTime();
          if (startDate && ts < new Date(startDate).getTime()) return false;
          if (endDate && ts > new Date(endDate).getTime()) return false;
          if (minAmount !== undefined && tx.amount < minAmount) return false;
          if (maxAmount !== undefined && tx.amount > maxAmount) return false;
          return true;
        });
      },

      clearAll: () => set({ transactions: [] })
    }),
    { name: 'securepay-transactions' }
  )
);

// Listen for cross-tab updates
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === 'securepay-transactions') {
      useTransactionStore.persist.rehydrate();
    }
  });
}
