import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthState {
  isAuthenticated: boolean;
  currentUserId: string | null;
  pin: string;
  attempts: number;
  lockUntil: number | null;
  // Actions
  loginAs: (userId: string, pin: string) => void;
  setPin: (pin: string) => void;
  verifyPin: (input: string) => boolean;
  logout: () => void;
  resetAttempts: () => void;
}

const MAX_ATTEMPTS = Number(import.meta.env.VITE_MAX_LOGIN_ATTEMPTS) || 3;
const LOCK_DURATION_MS = Number(import.meta.env.VITE_LOCK_DURATION_MS) || (5 * 60 * 1000); // 5 minutes

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      isAuthenticated: false,
      currentUserId: null,
      pin: import.meta.env.VITE_DEFAULT_PIN || '123456',
      attempts: 0,
      lockUntil: null,

      loginAs: (userId, pin) => set({ currentUserId: userId, pin, isAuthenticated: true, attempts: 0, lockUntil: null }),

      setPin: (pin) => set({ pin }),

      verifyPin: (input) => {
        const { pin, attempts, lockUntil } = get();

        // Check if locked
        if (lockUntil && Date.now() < lockUntil) return false;

        if (input === pin) {
          set({ isAuthenticated: true, attempts: 0, lockUntil: null });
          return true;
        } else {
          const newAttempts = attempts + 1;
          if (newAttempts >= MAX_ATTEMPTS) {
            set({ attempts: newAttempts, lockUntil: Date.now() + LOCK_DURATION_MS });
          } else {
            set({ attempts: newAttempts });
          }
          return false;
        }
      },

      logout: () => set({ isAuthenticated: false, currentUserId: null }),

      resetAttempts: () => set({ attempts: 0, lockUntil: null }),
    }),
    { name: 'securepay-auth' }
  )
);
