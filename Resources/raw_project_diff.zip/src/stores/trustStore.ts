import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { FraudFlag } from '@/types';

interface TrustState {
  flags: FraudFlag[];
  addFlag: (flag: FraudFlag) => void;
  removeFlag: (id: string) => void;
  getFlagsInLast30Days: (userId: string) => FraudFlag[];
  getUserFlags: (userId: string) => FraudFlag[];
  clearAll: () => void;
}

export const useTrustStore = create<TrustState>()(
  persist(
    (set, get) => ({
      flags: [],

      addFlag: (flag) => set((state) => ({ flags: [flag, ...state.flags] })),

      removeFlag: (id) =>
        set((state) => ({ flags: state.flags.filter((f) => f.id !== id) })),

      getUserFlags: (userId) => {
        return get().flags.filter(f => f.userId === userId);
      },

      getFlagsInLast30Days: (userId) => {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        return get().getUserFlags(userId).filter(
          (f) => new Date(f.timestamp) > thirtyDaysAgo
        );
      },

      clearAll: () => set({ flags: [] })
    }),
    { name: 'securepay-trust' }
  )
);
