/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_FIREBASE_API_KEY: string;
  readonly VITE_FIREBASE_AUTH_DOMAIN: string;
  readonly VITE_FIREBASE_PROJECT_ID: string;
  readonly VITE_FIREBASE_STORAGE_BUCKET: string;
  readonly VITE_FIREBASE_MESSAGING_SENDER_ID: string;
  readonly VITE_FIREBASE_APP_ID: string;
  readonly VITE_GEMINI_API_KEY: string;
  readonly VITE_MAX_LOGIN_ATTEMPTS: string;
  readonly VITE_LOCK_DURATION_MS: string;
  readonly VITE_DEFAULT_PIN: string;
  readonly VITE_FRAUD_SUSPENSION_THRESHOLD: string;
  readonly VITE_TRUST_SCORE_PENALTY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
