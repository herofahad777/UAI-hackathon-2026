// Utility functions for SecurePay

/** Format amount in Indian Rupees */
export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

/** Format short amount (e.g. ₹1.2K, ₹2.5L) */
export function formatShortINR(amount: number): string {
  if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(1)}Cr`;
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(1)}L`;
  if (amount >= 1000) return `₹${(amount / 1000).toFixed(1)}K`;
  return `₹${amount}`;
}

/** Format date to readable Indian format */
export function formatDate(isoString: string): string {
  return new Date(isoString).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

/** Format time */
export function formatTime(isoString: string): string {
  return new Date(isoString).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
}

/** Format date + time */
export function formatDateTime(isoString: string): string {
  return `${formatDate(isoString)} at ${formatTime(isoString)}`;
}

/** Get trust score color */
export function getTrustColor(score: number): string {
  if (score >= 80) return '#10b981'; // green
  if (score >= 60) return '#f59e0b'; // amber
  if (score >= 40) return '#f97316'; // orange
  return '#ef4444'; // red
}

/** Get trust label */
export function getTrustLabel(score: number): string {
  if (score >= 80) return 'Highly Trusted';
  if (score >= 60) return 'Moderate Trust';
  if (score >= 40) return 'Low Trust';
  return 'Untrusted';
}

/** Generate a unique transaction ID */
export function generateTxId(): string {
  return `tx-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
}

/** Validate UPI ID format */
export function isValidUpiId(upiId: string): boolean {
  return /^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+$/.test(upiId);
}

/** Validate IFSC code */
export function isValidIFSC(ifsc: string): boolean {
  return /^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc.toUpperCase());
}

/** Get initials from name */
export function getInitials(name: string): string {
  if (!name) return '??';
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0])
    .join('')
    .toUpperCase() || '??';
}

/** Mask account number */
export function maskAccountNumber(accountNumber: string): string {
  return '•'.repeat(accountNumber.length - 4) + accountNumber.slice(-4);
}

/** Get random avatar color from name */
export function getAvatarColor(name: string): string {
  const colors = [
    '#6366f1', '#8b5cf6', '#ec4899', '#f59e0b',
    '#10b981', '#06b6d4', '#f97316', '#84cc16',
  ];
  const index = name.charCodeAt(0) % colors.length;
  return colors[index];
}
