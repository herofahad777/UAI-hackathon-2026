// Core TypeScript types for SecurePay

export interface User {
  id: string;
  name: string;
  phone: string;
  upiId: string;
  balance: number;
  trustScore: number;
  isSuspended: boolean;
  suspendedAt?: string;
  createdAt: string;
}

export interface FraudFlag {
  id: string;
  userId: string;
  reason: string;
  timestamp: string;
  triggeredBy: 'auto' | 'report';
  transactionId?: string;
}

export interface Transaction {
  id: string;
  fromUserId: string;
  toUserId: string;
  toName: string;
  toUpiId: string;
  amount: number;
  method: 'qr' | 'contact' | 'mobile' | 'bank';
  status: 'success' | 'failed' | 'cancelled' | 'pending';
  timestamp: string;
  trustScoreAtTime: number;
  isSuspected: boolean;
  fraudFlags: string[];
  note?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export type PaymentMethod = 'qr' | 'contact' | 'mobile' | 'bank';

export interface Contact {
  id: string;
  name: string;
  phone: string;
  upiId: string;
  recentAmount?: number;
}

export interface BankAccount {
  accountNumber: string;
  ifscCode: string;
  accountHolderName: string;
  bankName: string;
}

export interface FraudDetectionResult {
  isFraud: boolean;
  reasons: string[];
}

export interface EmergencyContact {
  name: string;
  number: string;
  icon: string;
  description: string;
}
