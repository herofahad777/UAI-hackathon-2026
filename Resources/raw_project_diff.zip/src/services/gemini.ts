// Gemini API Service – Finance-only AI Advisor

const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || '';
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent';

const SYSTEM_PROMPT = `You are a certified financial advisor for SecurePay, an Indian digital payment platform. 
Answer ONLY questions related to personal finance, budgeting, investments, UPI safety, digital payments, tax planning (Indian context), and fraud prevention.
Keep responses concise, practical, and relevant to Indian financial context.
Never give medical, legal, or unrelated advice.
If user asks anything outside finance/payments, reply: "I can only help with financial and payment-related matters. Please ask me about budgeting, investments, UPI safety or tax planning."
Always mention relevant Indian regulations, RBI guidelines, or NPCI rules when applicable.`;

export interface GeminiMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}

export async function sendToGemini(
  userMessage: string,
  history: GeminiMessage[]
): Promise<string> {
  if (!GEMINI_API_KEY) {
    return "⚠️ Gemini API key not configured. Please add VITE_GEMINI_API_KEY to your .env file to enable the AI Advisor.";
  }

  try {
    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents: [
          ...history,
          { role: 'user', parts: [{ text: userMessage }] },
        ],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 800,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    return data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      "I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error('Gemini API error:', error);
    return "Unable to connect to the AI Advisor right now. Please check your API key and internet connection.";
  }
}
