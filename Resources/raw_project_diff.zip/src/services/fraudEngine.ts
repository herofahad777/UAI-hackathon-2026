import { Transaction, FraudDetectionResult } from '@/types';

/** Client-side Fraud Detection Engine */
export function detectFraud(
  amount: number,
  recentTransactions: Transaction[],
  allTransactions: Transaction[]
): FraudDetectionResult {
  const reasons: string[] = [];

  // Rule 1: Large transaction
  if (amount > 50000) {
    reasons.push('Transaction exceeds ₹50,000 limit');
  }

  // Rule 2: Frequency – more than 5 transactions in the last 10 minutes
  const tenMinAgo = Date.now() - 10 * 60 * 1000;
  const recentCount = recentTransactions.filter(
    (tx) => new Date(tx.timestamp).getTime() > tenMinAgo
  ).length;
  if (recentCount >= 5) {
    reasons.push('Unusual frequency: more than 5 transactions in 10 minutes');
  }

  // Rule 3: Unusual timing (2 AM – 5 AM IST)
  const hour = new Date().getHours();
  if (hour >= 2 && hour < 5) {
    reasons.push('Unusual transaction timing (2 AM – 5 AM)');
  }

  // Rule 4: Sudden amount spike – more than 3x the user's average
  if (allTransactions.length >= 3) {
    const successfulTxs = allTransactions.filter((tx) => tx.status === 'success');
    if (successfulTxs.length >= 3) {
      const avgAmount =
        successfulTxs.reduce((acc, tx) => acc + tx.amount, 0) / successfulTxs.length;
      const stdDev = Math.sqrt(
        successfulTxs.reduce((acc, tx) => acc + Math.pow(tx.amount - avgAmount, 2), 0) /
          successfulTxs.length
      );
      if (amount > avgAmount + 3 * stdDev && amount > 5000) {
        reasons.push(`Amount spike detected: ₹${amount.toLocaleString('en-IN')} is significantly above your average`);
      }
    }
  }

  return {
    isFraud: reasons.length > 0,
    reasons,
  };
}

/** Calculate trust impact and return new trust score */
export function calculateNewTrustScore(
  currentScore: number,
  flagsInLast30Days: number
): number {
  // Each flag drops trust by 20%
  const drop = Number(import.meta.env.VITE_TRUST_SCORE_PENALTY) || 20;
  return Math.max(0, currentScore - drop);
}

/** Check if account should be suspended (2+ flags in 30 days) */
export function shouldSuspendAccount(flagsInLast30Days: number): boolean {
  const threshold = Number(import.meta.env.VITE_FRAUD_SUSPENSION_THRESHOLD) || 2;
  return flagsInLast30Days >= threshold;
}
