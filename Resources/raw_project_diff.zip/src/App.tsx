import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from '@/stores/authStore';
import { useUserStore } from '@/stores/userStore';

// Pages
import AccountSelectionPage from '@/pages/AccountSelectionPage';
import AdminSettingsPage from '@/pages/AdminSettingsPage';
import PinScreen from '@/pages/PinScreen';
import Dashboard from '@/pages/Dashboard';
import PaymentPage from '@/pages/PaymentPage';
import TransactionHistory from '@/pages/TransactionHistory';
import TransactionDetailPage from '@/pages/TransactionDetailPage';
import EmergencyPage from '@/pages/EmergencyPage';
import AIAdvisorPage from '@/pages/AIAdvisorPage';
import LegalPage from '@/pages/LegalPage';

// Layout
import AppShell from '@/components/layout/AppShell';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, currentUserId } = useAuthStore();
  if (!isAuthenticated || !currentUserId) return <Navigate to="/" replace />;
  return <>{children}</>;
}

function SuspendedRoute({ children }: { children: React.ReactNode }) {
  const { currentUserId } = useAuthStore();
  const accounts = useUserStore((s) => s.accounts);
  const user = accounts.find(a => a.id === currentUserId);
  
  if (user?.isSuspended) return <Navigate to="/legal" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="app-container">
        <Routes>
          {/* Public / Entry Routes */}
          <Route path="/" element={<AccountSelectionPage />} />
          <Route path="/admin" element={<AdminSettingsPage />} />
          <Route path="/login/:id" element={<PinScreen />} />

          {/* Protected Routes */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <SuspendedRoute>
                  <AppShell>
                    <Dashboard />
                  </AppShell>
                </SuspendedRoute>
              </ProtectedRoute>
            }
          />
          <Route
            path="/pay"
            element={
              <ProtectedRoute>
                <SuspendedRoute>
                  <AppShell>
                    <PaymentPage />
                  </AppShell>
                </SuspendedRoute>
              </ProtectedRoute>
            }
          />
          <Route
            path="/pay/:method"
            element={
              <ProtectedRoute>
                <SuspendedRoute>
                  <AppShell>
                    <PaymentPage />
                  </AppShell>
                </SuspendedRoute>
              </ProtectedRoute>
            }
          />
          <Route
            path="/history"
            element={
              <ProtectedRoute>
                <AppShell>
                  <TransactionHistory />
                </AppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/history/:id"
            element={
              <ProtectedRoute>
                <AppShell>
                  <TransactionDetailPage />
                </AppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/emergency"
            element={
              <ProtectedRoute>
                <AppShell>
                  <EmergencyPage />
                </AppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/advisor"
            element={
              <ProtectedRoute>
                <AppShell>
                  <AIAdvisorPage />
                </AppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/legal"
            element={
              <ProtectedRoute>
                <AppShell>
                  <LegalPage />
                </AppShell>
              </ProtectedRoute>
            }
          />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
