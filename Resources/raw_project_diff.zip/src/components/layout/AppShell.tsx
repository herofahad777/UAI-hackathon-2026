import { useLocation } from 'react-router-dom';
import BottomNav from './BottomNav';

interface AppShellProps {
  children: React.ReactNode;
}

export default function AppShell({ children }: AppShellProps) {
  const location = useLocation();
  const hideNav = location.pathname === '/advisor';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', background: 'var(--bg-primary)' }}>
      <main style={{ flex: 1, overflowY: 'auto', paddingBottom: hideNav ? 0 : '80px' }}>
        {children}
      </main>
      {!hideNav && <BottomNav />}
    </div>
  );
}
