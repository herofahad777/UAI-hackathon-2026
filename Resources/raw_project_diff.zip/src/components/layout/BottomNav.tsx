import { NavLink, useNavigate } from 'react-router-dom';
import { Home, Clock, PhoneCall, Sparkles, Send } from 'lucide-react';

const navItems = [
  { path: '/dashboard', icon: Home, label: 'Home' },
  { path: '/pay', icon: Send, label: 'Pay' },
  { path: '/history', icon: Clock, label: 'History' },
  { path: '/advisor', icon: Sparkles, label: 'Advisor' },
  { path: '/emergency', icon: PhoneCall, label: 'Emergency' },
];

export default function BottomNav() {
  return (
    <nav
      style={{
        position: 'fixed',
        bottom: 0,
        left: '50%',
        transform: 'translateX(-50%)',
        width: '100%',
        maxWidth: 430,
        background: 'rgba(18,18,31,0.95)',
        backdropFilter: 'blur(20px)',
        borderTop: '1px solid rgba(255,255,255,0.08)',
        padding: '8px 0 12px',
        zIndex: 50,
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center' }}>
        {navItems.map(({ path, icon: Icon, label }) => (
          <NavLink
            key={path}
            to={path}
            style={({ isActive }) => ({
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 4,
              padding: '6px 16px',
              borderRadius: 12,
              textDecoration: 'none',
              color: isActive ? '#6366f1' : '#475569',
              fontWeight: isActive ? 700 : 500,
              fontSize: 10,
              transition: 'all 0.2s ease',
            })}
          >
            {({ isActive }) => (
              <>
                <div
                  style={{
                    background: isActive ? 'rgba(99,102,241,0.15)' : 'transparent',
                    borderRadius: 10,
                    padding: '6px 8px',
                    transition: 'all 0.2s ease',
                  }}
                >
                  <Icon size={20} />
                </div>
                <span>{label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
