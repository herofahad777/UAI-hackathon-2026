import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuthStore } from '@/stores/authStore';
import { useUserStore } from '@/stores/userStore';
import { Shield, Fingerprint, Delete, ArrowLeft } from 'lucide-react';

const KEYS = ['1','2','3','4','5','6','7','8','9','','0','⌫'];

export default function PinScreen() {
  const { id } = useParams<{ id: string }>();
  const [pin, setPin] = useState('');
  const [shake, setShake] = useState(false);
  const [error, setError] = useState('');
  const [timeLeft, setTimeLeft] = useState(0);
  const navigate = useNavigate();
  
  const { accounts } = useUserStore();
  const { loginAs, isAuthenticated, currentUserId, logout } = useAuthStore();
  
  // Local state for auth, mimicking the store behavior for the specific user
  // (In a real app, lockUntil/attempts would be per-user in the backend)
  const [attempts, setAttempts] = useState(0);
  const [lockUntil, setLockUntil] = useState<number | null>(null);
  
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const selectedUser = accounts.find(a => a.id === id);

  useEffect(() => {
    if (!selectedUser) {
      navigate('/');
    }
  }, [selectedUser, navigate]);

  // Redirect if already authenticated as this user, otherwise logout the old session
  useEffect(() => {
    if (isAuthenticated && currentUserId === id) {
      navigate('/dashboard', { replace: true });
    } else if (isAuthenticated && currentUserId !== id) {
      logout();
    }
  }, [isAuthenticated, currentUserId, id, navigate, logout]);

  // Lockout countdown
  useEffect(() => {
    if (lockUntil && lockUntil > Date.now()) {
      const update = () => {
        const remaining = Math.ceil((lockUntil - Date.now()) / 1000);
        setTimeLeft(remaining > 0 ? remaining : 0);
        if (remaining <= 0) {
          clearInterval(timerRef.current!);
          setError('');
          setLockUntil(null);
          setAttempts(0);
        }
      };
      update();
      timerRef.current = setInterval(update, 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [lockUntil]);

  const isLocked = lockUntil !== null && lockUntil > Date.now();

  const handleKey = (key: string) => {
    if (isLocked) return;
    if (key === '⌫') {
      setPin((p) => p.slice(0, -1));
      return;
    }
    if (pin.length >= 6) return;
    const newPin = pin + key;
    setPin(newPin);
    if (newPin.length === 6) {
      setTimeout(() => checkPin(newPin), 100);
    }
  };

  const checkPin = (input: string) => {
    // Hardcoded PIN for demo purposes for all accounts
    const defaultPin = import.meta.env.VITE_DEFAULT_PIN || '123456';
    const correct = input === defaultPin;
    if (correct) {
      if (selectedUser) {
        loginAs(selectedUser.id, defaultPin);
      }
      navigate('/dashboard', { replace: true });
    } else {
      setShake(true);
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      
      const maxAttempts = Number(import.meta.env.VITE_MAX_LOGIN_ATTEMPTS) || 3;
      const remaining = maxAttempts - newAttempts;
      
      if (remaining > 0) {
        setError(`Wrong PIN. ${remaining} attempt${remaining > 1 ? 's' : ''} left.`);
      } else {
        const lockMs = Number(import.meta.env.VITE_LOCK_DURATION_MS) || (5 * 60 * 1000);
        setError(`Account locked for ${Math.round(lockMs / 60000)} minutes.`);
        setLockUntil(Date.now() + lockMs);
      }
      setTimeout(() => { setShake(false); setPin(''); }, 500);
    }
  };

  const formatLockTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  if (!selectedUser) return null;

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'space-between',
        minHeight: '100vh',
        padding: '60px 24px 40px',
        background: 'linear-gradient(180deg, #0a0a14 0%, #12121f 100%)',
        position: 'relative',
      }}
    >
      <button 
        onClick={() => navigate('/')}
        style={{ position: 'absolute', top: 20, left: 20, background: 'rgba(255,255,255,0.05)', border: '1px solid var(--border-subtle)', borderRadius: 12, padding: 10, cursor: 'pointer', color: 'var(--text-secondary)' }}
      >
        <ArrowLeft size={20} />
      </button>

      {/* Logo & User info */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
        <div
          style={{
            width: 72,
            height: 72,
            background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
            borderRadius: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 40px rgba(99,102,241,0.4)',
          }}
        >
          <Shield size={36} color="white" />
        </div>
        <div style={{ textAlign: 'center' }}>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--text-primary)' }}>
            Welcome back, {selectedUser.name.split(' ')[0]}
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginTop: 4 }}>
            {selectedUser.upiId}
          </p>
        </div>
      </div>

      {/* PIN Area */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 32, width: '100%' }}>
        <div>
          <p style={{ textAlign: 'center', color: 'var(--text-secondary)', marginBottom: 24, fontSize: 15 }}>
            {isLocked ? `🔒 Locked – try again in ${formatLockTime(timeLeft)}` : 'Enter your 6-digit PIN'}
          </p>

          {/* PIN Dots */}
          <div
            style={{ display: 'flex', gap: 16, justifyContent: 'center' }}
            className={shake ? 'shake' : ''}
          >
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                style={{
                  width: 16,
                  height: 16,
                  borderRadius: '50%',
                  background: i < pin.length ? '#6366f1' : 'transparent',
                  border: '2px solid',
                  borderColor: i < pin.length ? '#6366f1' : 'rgba(255,255,255,0.3)',
                  transition: 'all 0.15s ease',
                  transform: i < pin.length ? 'scale(1.1)' : 'scale(1)',
                  boxShadow: i < pin.length ? '0 0 10px rgba(99,102,241,0.6)' : 'none',
                }}
              />
            ))}
          </div>

          {/* Error */}
          {error && (
            <p style={{ textAlign: 'center', color: '#ef4444', fontSize: 13, marginTop: 16 }}>
              {error}
            </p>
          )}
        </div>

        {/* Keypad */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 16,
            width: '100%',
            maxWidth: 300,
          }}
        >
          {KEYS.map((key, idx) => (
            <button
              key={idx}
              onClick={() => key && handleKey(key)}
              disabled={isLocked || key === ''}
              style={{
                height: 72,
                borderRadius: 18,
                background: key === '' ? 'transparent' : key === '⌫' ? 'rgba(239,68,68,0.1)' : 'rgba(255,255,255,0.05)',
                border: key === '' ? 'none' : '1px solid rgba(255,255,255,0.08)',
                color: key === '⌫' ? '#ef4444' : 'var(--text-primary)',
                fontSize: 22,
                fontWeight: 600,
                cursor: key === '' || isLocked ? 'default' : 'pointer',
                transition: 'all 0.15s ease',
                fontFamily: 'var(--font-main)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: isLocked ? 0.4 : 1,
              }}
            >
              {key === '⌫' ? <Delete size={22} /> : key}
            </button>
          ))}
        </div>

        {/* Biometric hint */}
        <button
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            background: 'transparent',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 12,
            color: 'var(--text-secondary)',
            padding: '10px 20px',
            fontSize: 13,
            cursor: 'pointer',
            fontFamily: 'var(--font-main)',
          }}
          onClick={() => {
            // Simulate biometric success
            checkPin(import.meta.env.VITE_DEFAULT_PIN || '123456');
          }}
        >
          <Fingerprint size={18} />
          Use Biometric
        </button>
      </div>

      <p style={{ color: 'var(--text-muted)', fontSize: 12, textAlign: 'center' }}>
        Default PIN: {import.meta.env.VITE_DEFAULT_PIN || '123456'}
      </p>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-10px); }
          40% { transform: translateX(10px); }
          60% { transform: translateX(-6px); }
          80% { transform: translateX(6px); }
        }
        .shake { animation: shake 0.4s ease; }
      `}</style>
    </div>
  );
}
