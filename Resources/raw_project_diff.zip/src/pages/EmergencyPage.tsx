import { PhoneCall, Shield, AlertTriangle, ExternalLink, ChevronRight } from 'lucide-react';

const EMERGENCY_CONTACTS = [
  {
    name: 'Cyber Crime',
    number: '1930',
    icon: '🛡️',
    description: 'National Cyber Crime Helpline – report online fraud, UPI & banking scams',
    color: '#6366f1',
    bg: 'rgba(99,102,241,0.1)',
  },
  {
    name: 'Police',
    number: '100',
    icon: '🚔',
    description: 'Emergency police assistance for urgent financial crimes',
    color: '#ef4444',
    bg: 'rgba(239,68,68,0.1)',
  },
  {
    name: 'RBI Ombudsman',
    number: '155260',
    icon: '🏛️',
    description: 'Reserve Bank of India Banking Ombudsman – banking & UPI complaints',
    color: '#10b981',
    bg: 'rgba(16,185,129,0.1)',
  },
];

const STEPS = [
  { step: 1, title: 'Do not panic', desc: 'Stay calm. Immediately pause any ongoing transactions and secure your account.' },
  { step: 2, title: 'Call 1930 immediately', desc: 'Report to the National Cyber Crime Helpline within 24 hours for the best chance of fund recovery.' },
  { step: 3, title: 'Block your UPI', desc: 'Contact your bank to freeze your UPI-linked account if the fraud involved unauthorized access.' },
  { step: 4, title: 'File FIR', desc: 'Visit your nearest police station or file an online FIR at cybercrime.gov.in.' },
  { step: 5, title: 'Keep evidence', desc: 'Screenshot all transaction details, fraudulent messages, and communications.' },
  { step: 6, title: 'Report to NPCI', desc: 'Report UPI fraud via your bank\'s app or at NPCI grievance portal.' },
];

export default function EmergencyPage() {
  const handleCall = (number: string) => {
    window.location.href = `tel:${number}`;
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', padding: '50px 0 0' }}>
      {/* Header */}
      <div style={{ padding: '0 20px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 6 }}>
          <div style={{ width: 40, height: 40, background: 'rgba(239,68,68,0.15)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <AlertTriangle size={20} color="#ef4444" />
          </div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Emergency Help</h1>
        </div>
        <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>
          Been scammed? Act fast. Call these official numbers immediately.
        </p>
      </div>

      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 20 }}>
        {/* Emergency Call Buttons */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {EMERGENCY_CONTACTS.map((contact) => (
            <button
              key={contact.number}
              onClick={() => handleCall(contact.number)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 16,
                background: contact.bg,
                border: `1px solid ${contact.color}30`,
                borderRadius: 20,
                padding: '16px 20px',
                cursor: 'pointer',
                textAlign: 'left',
                fontFamily: 'var(--font-main)',
                width: '100%',
                transition: 'all 0.2s',
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(1.01)'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(1)'; }}
            >
              <div style={{ fontSize: 32, lineHeight: 1 }}>{contact.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
                  <p style={{ fontSize: 18, fontWeight: 800, color: contact.color }}>{contact.number}</p>
                  <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{contact.name}</p>
                </div>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.4 }}>{contact.description}</p>
              </div>
              <div style={{ flexShrink: 0, width: 36, height: 36, background: contact.color, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <PhoneCall size={16} color="white" />
              </div>
            </button>
          ))}
        </div>

        {/* Cybercrime portal link */}
        <a
          href="https://cybercrime.gov.in"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            background: 'rgba(99,102,241,0.08)',
            border: '1px solid rgba(99,102,241,0.2)',
            borderRadius: 16,
            padding: '14px 16px',
            textDecoration: 'none',
          }}
        >
          <Shield size={20} color="#6366f1" />
          <div style={{ flex: 1 }}>
            <p style={{ color: '#6366f1', fontWeight: 700, fontSize: 14 }}>cybercrime.gov.in</p>
            <p style={{ color: 'var(--text-muted)', fontSize: 12 }}>File online complaint at National Cyber Crime Reporting Portal</p>
          </div>
          <ExternalLink size={16} color="#6366f1" />
        </a>

        {/* Step-by-step protocol */}
        <div>
          <p style={{ color: 'var(--text-secondary)', fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 12 }}>
            What to do if you've been scammed
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {STEPS.map(({ step, title, desc }) => (
              <div
                key={step}
                style={{
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: 16,
                  padding: '14px 16px',
                  display: 'flex',
                  gap: 14,
                  alignItems: 'flex-start',
                }}
              >
                <div
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 12,
                    fontWeight: 800,
                    color: 'white',
                    flexShrink: 0,
                  }}
                >
                  {step}
                </div>
                <div>
                  <p style={{ fontSize: 13, fontWeight: 700, marginBottom: 2 }}>{title}</p>
                  <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.5 }}>{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
