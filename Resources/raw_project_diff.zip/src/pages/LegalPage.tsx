import { useState } from 'react';
import { useUserStore } from '@/stores/userStore';
import { useNavigate } from 'react-router-dom';
import { Scale, FileText, Send, CheckCircle, AlertTriangle, LogOut } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';

export default function LegalPage() {
  const { currentUserId, logout } = useAuthStore();
  const { accounts, addAppeal } = useUserStore();
  const currentUser = accounts.find(a => a.id === currentUserId);
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: currentUser?.name || '', reason: '', details: '' });
  const [submitted, setSubmitted] = useState(false);

  if (!currentUser) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addAppeal({
      userId: currentUser.id,
      name: formData.name,
      reason: formData.reason,
      details: formData.details
    });
    setSubmitted(true);
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', padding: '50px 16px 24px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
        <div style={{ width: 44, height: 44, background: 'rgba(245,158,11,0.15)', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Scale size={22} color="#f59e0b" />
        </div>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Legal Section</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: 12 }}>Account Review &amp; Appeal</p>
        </div>
      </div>

      {/* Suspension notice */}
      {currentUser.isSuspended && (
        <div style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 20, padding: '20px', marginBottom: 20 }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 12 }}>
            <AlertTriangle size={22} color="#ef4444" style={{ flexShrink: 0, marginTop: 2 }} />
            <div>
              <h2 style={{ color: '#ef4444', fontSize: 16, fontWeight: 700, marginBottom: 4 }}>Account Suspended</h2>
              <p style={{ color: 'rgba(239,68,68,0.8)', fontSize: 13, lineHeight: 1.5 }}>
                Your account has been suspended due to 2 or more fraud flags within 30 days.
                {currentUser.suspendedAt && (
                  <> Suspended on: <strong>{new Date(currentUser.suspendedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</strong></>
                )}
              </p>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button
              onClick={() => { logout(); navigate('/'); }}
              style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, background: 'none', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 12, padding: '10px', cursor: 'pointer', color: '#ef4444', fontSize: 13, fontFamily: 'var(--font-main)' }}
            >
              <LogOut size={14} /> Log Out
            </button>
          </div>
        </div>
      )}

      {/* What happens next */}
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-subtle)', borderRadius: 20, padding: '16px', marginBottom: 20 }}>
        <p style={{ color: 'var(--text-secondary)', fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 12 }}>How Appeals Work</p>
        {['Submit the appeal form below with your details', 'Our team reviews your account activity within 3–5 business days', 'If your appeal is successful, your account will be reinstated', 'If denied, you may contact your bank directly or approach RBI Ombudsman'].map((step, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, marginBottom: 10, alignItems: 'flex-start' }}>
            <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#6366f1', flexShrink: 0 }}>
              {i + 1}
            </div>
            <p style={{ color: 'var(--text-secondary)', fontSize: 13, lineHeight: 1.5, marginTop: 2 }}>{step}</p>
          </div>
        ))}
      </div>

      {/* Appeal Form */}
      {!submitted ? (
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <p style={{ fontSize: 16, fontWeight: 700, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
              <FileText size={18} color="#6366f1" /> Submit Appeal
            </p>
          </div>
          <div>
            <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Full Name</label>
            <input className="input" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} required />
          </div>
          <div>
            <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Reason for Appeal</label>
            <select
              className="input"
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              required
              style={{ appearance: 'none' }}
            >
              <option value="">Select a reason…</option>
              <option value="false_flag">Transactions were falsely flagged as fraud</option>
              <option value="hacked">My account may have been compromised</option>
              <option value="victim">I was a victim of fraud, not the perpetrator</option>
              <option value="error">System error or incorrect suspension</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Detailed Explanation</label>
            <textarea
              className="input"
              placeholder="Explain your situation in detail. Include any relevant transaction IDs, dates, or other information that supports your appeal."
              value={formData.details}
              onChange={(e) => setFormData({ ...formData, details: e.target.value })}
              required
              rows={5}
              style={{ resize: 'none', height: 'auto' }}
            />
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: 12, lineHeight: 1.5 }}>
            ⚠️ By submitting this form, you confirm that all information provided is accurate. False appeals may result in permanent account closure.
          </p>
          <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
            <Send size={16} /> Submit Appeal to Bank
          </button>
        </form>
      ) : (
        <div style={{ textAlign: 'center', padding: '40px 24px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
          <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'rgba(16,185,129,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <CheckCircle size={40} color="#10b981" />
          </div>
          <h3 style={{ fontSize: 18, fontWeight: 700 }}>Appeal Submitted</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13, lineHeight: 1.6 }}>
            Your appeal has been forwarded to the bank's legal team. You will receive a response within 3–5 business days. Keep your phone number accessible for verification.
          </p>
          <p style={{ color: 'var(--text-muted)', fontSize: 12, fontStyle: 'italic' }}>
            Reference ID: SECP-{Date.now().toString().slice(-8)}
          </p>
        </div>
      )}
    </div>
  );
}
