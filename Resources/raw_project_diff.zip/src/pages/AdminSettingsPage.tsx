import { useNavigate } from 'react-router-dom';
import { useUserStore } from '@/stores/userStore';
import { useAuthStore } from '@/stores/authStore';
import { useTransactionStore } from '@/stores/transactionStore';
import { useTrustStore } from '@/stores/trustStore';
import { Settings, Trash2, ArrowLeft, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

export default function AdminSettingsPage() {
  const navigate = useNavigate();
  const { appeals, resolveAppeal, reinstateAccount } = useUserStore();
  const logout = useAuthStore(s => s.logout);
  const clearAuth = useAuthStore.persist.clearStorage;
  const clearUsers = useUserStore.persist.clearStorage;
  const clearTx = useTransactionStore.persist.clearStorage;
  const clearTrust = useTrustStore.persist.clearStorage;

  const handleClearAll = () => {
    if (window.confirm("Are you sure? This will wipe all accounts, transactions, and settings, returning the app to its default state.")) {
      logout();
      clearAuth();
      clearUsers();
      clearTx();
      clearTrust();
      window.location.href = '/'; // hard reload to clear memory state
    }
  };

  const handleResolve = (id: string, userId: string, status: 'approved' | 'rejected') => {
    resolveAppeal(id, status);
    if (status === 'approved') {
      reinstateAccount(userId);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', padding: '50px 16px 24px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 32 }}>
        <button onClick={() => navigate(-1)} style={{ background: 'var(--bg-card)', border: '1px solid var(--border-subtle)', borderRadius: 12, padding: 8, cursor: 'pointer', color: 'var(--text-primary)' }}>
          <ArrowLeft size={18} />
        </button>
        <div style={{ width: 44, height: 44, background: 'rgba(99,102,241,0.15)', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Settings size={22} color="#6366f1" />
        </div>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Admin Settings</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: 12 }}>Developer & Debug Panel</p>
        </div>
      </div>

      {/* Clear Data */}
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-subtle)', borderRadius: 20, padding: 20, marginBottom: 32 }}>
        <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8, color: '#ef4444' }}>Danger Zone</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 16 }}>
          Wipe all local storage data to reset the demo completely. This action cannot be undone.
        </p>
        <button 
          onClick={handleClearAll}
          style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 12, padding: 14, cursor: 'pointer', color: '#ef4444', fontWeight: 600, fontFamily: 'var(--font-main)' }}
        >
          <Trash2 size={18} /> Clear All Local Data
        </button>
      </div>

      {/* Appeals */}
      <div>
        <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Pending Appeals ({appeals.filter(a => a.status === 'pending').length})</h2>
        
        {appeals.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px 20px', border: '1px dashed var(--border-main)', borderRadius: 20 }}>
            <AlertCircle size={30} color="var(--text-muted)" style={{ marginBottom: 10 }} />
            <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>No legal appeals have been submitted.</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {appeals.map(a => (
              <div key={a.id} style={{ background: 'var(--bg-card)', border: '1px solid var(--border-subtle)', borderRadius: 20, padding: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
                  <div>
                    <p style={{ fontSize: 15, fontWeight: 700 }}>{a.name}</p>
                    <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>ID: {a.id}</p>
                  </div>
                  {a.status === 'pending' ? (
                    <span style={{ fontSize: 11, background: 'rgba(245,158,11,0.1)', color: '#f59e0b', padding: '4px 8px', borderRadius: 8, fontWeight: 700 }}>PENDING</span>
                  ) : (
                    <span style={{ fontSize: 11, background: a.status === 'approved' ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)', color: a.status === 'approved' ? '#10b981' : '#ef4444', padding: '4px 8px', borderRadius: 8, fontWeight: 700 }}>
                      {a.status.toUpperCase()}
                    </span>
                  )}
                </div>
                
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 4 }}><strong>Reason:</strong> {a.reason.replace('_', ' ')}</p>
                <p style={{ fontSize: 13, color: 'var(--text-primary)', marginBottom: 16, background: 'var(--bg-elevated)', padding: 10, borderRadius: 8 }}>"{a.details}"</p>

                {a.status === 'pending' && (
                  <div style={{ display: 'flex', gap: 10 }}>
                    <button 
                      onClick={() => handleResolve(a.id, a.userId, 'rejected')}
                      style={{ flex: 1, display: 'flex', justifyContent: 'center', gap: 6, background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', color: '#ef4444', padding: 10, borderRadius: 12, fontWeight: 600, cursor: 'pointer' }}
                    >
                      <XCircle size={16} /> Reject
                    </button>
                    <button 
                      onClick={() => handleResolve(a.id, a.userId, 'approved')}
                      style={{ flex: 1, display: 'flex', justifyContent: 'center', gap: 6, background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.3)', color: '#10b981', padding: 10, borderRadius: 12, fontWeight: 600, cursor: 'pointer' }}
                    >
                      <CheckCircle size={16} /> Approve & Unban
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
