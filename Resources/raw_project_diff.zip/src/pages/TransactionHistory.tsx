import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTransactionStore } from '@/stores/transactionStore';
import { useAuthStore } from '@/stores/authStore';
import { formatINR, formatDate, formatTime } from '@/utils';
import { ArrowLeft, Filter, CheckCircle, XCircle, AlertOctagon, Clock } from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';
import { Transaction } from '@/types';

export default function TransactionHistory() {
  const navigate = useNavigate();
  const { currentUserId } = useAuthStore();
  const { filterTransactions, transactions } = useTransactionStore();
  const [showFilters, setShowFilters] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [minAmount, setMinAmount] = useState('');
  const [maxAmount, setMaxAmount] = useState('');

  const filtered = (startDate || endDate || minAmount || maxAmount)
    ? filterTransactions(currentUserId || 'global', {
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        minAmount: minAmount ? parseFloat(minAmount) : undefined,
        maxAmount: maxAmount ? parseFloat(maxAmount) : undefined,
      })
    : transactions; // Show global transactions by default for demo

  // Chart data – daily totals
  const chartData = buildChartData(filtered);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', padding: '50px 0 0' }}>
      {/* Header */}
      <div style={{ padding: '0 20px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={() => navigate(-1)} style={{ background: 'var(--bg-card)', border: '1px solid var(--border-subtle)', borderRadius: 12, padding: 8, cursor: 'pointer', color: 'var(--text-primary)' }}>
            <ArrowLeft size={18} />
          </button>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Transaction History</h1>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          style={{
            background: showFilters ? 'rgba(99,102,241,0.15)' : 'var(--bg-card)',
            border: `1px solid ${showFilters ? 'rgba(99,102,241,0.3)' : 'var(--border-subtle)'}`,
            borderRadius: 12,
            padding: '8px 12px',
            cursor: 'pointer',
            color: showFilters ? '#6366f1' : 'var(--text-secondary)',
            fontFamily: 'var(--font-main)',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            fontSize: 13,
          }}
        >
          <Filter size={15} /> Filters
        </button>
      </div>

      {/* Chart */}
      <div style={{ padding: '0 16px', marginBottom: 16 }}>
        <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '16px 10px 10px', border: '1px solid var(--border-subtle)' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px', paddingLeft: 8, marginBottom: 12 }}>
            Spending – Last 7 Days
          </p>
          <ResponsiveContainer width="100%" height={120}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="spendGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="date" stroke="#475569" tick={{ fontSize: 10, fill: '#475569' }} />
              <YAxis stroke="#475569" tick={{ fontSize: 10, fill: '#475569' }} tickFormatter={(v) => v >= 1000 ? `${v/1000}k` : v} />
              <Tooltip
                contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-main)', borderRadius: 10, color: 'var(--text-primary)' }}
                formatter={(value: number) => [formatINR(value), 'Amount']}
              />
              <Area type="monotone" dataKey="amount" stroke="#6366f1" strokeWidth={2} fill="url(#spendGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <div style={{ padding: '0 16px', marginBottom: 16 }}>
          <div style={{ background: 'var(--bg-card)', borderRadius: 18, padding: 16, border: '1px solid rgba(99,102,241,0.15)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: 11, display: 'block', marginBottom: 4 }}>From Date</label>
              <input type="date" className="input" value={startDate} onChange={(e) => setStartDate(e.target.value)} style={{ fontSize: 12, padding: '8px 10px' }} />
            </div>
            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: 11, display: 'block', marginBottom: 4 }}>To Date</label>
              <input type="date" className="input" value={endDate} onChange={(e) => setEndDate(e.target.value)} style={{ fontSize: 12, padding: '8px 10px' }} />
            </div>
            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: 11, display: 'block', marginBottom: 4 }}>Min Amount</label>
              <input type="number" className="input" placeholder="₹0" value={minAmount} onChange={(e) => setMinAmount(e.target.value)} style={{ fontSize: 12, padding: '8px 10px' }} />
            </div>
            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: 11, display: 'block', marginBottom: 4 }}>Max Amount</label>
              <input type="number" className="input" placeholder="₹∞" value={maxAmount} onChange={(e) => setMaxAmount(e.target.value)} style={{ fontSize: 12, padding: '8px 10px' }} />
            </div>
            <button
              onClick={() => { setStartDate(''); setEndDate(''); setMinAmount(''); setMaxAmount(''); }}
              style={{ gridColumn: '1 / -1', background: 'none', border: '1px solid var(--border-subtle)', borderRadius: 10, padding: '8px', color: 'var(--text-secondary)', cursor: 'pointer', fontSize: 12, fontFamily: 'var(--font-main)' }}
            >
              Clear Filters
            </button>
          </div>
        </div>
      )}

      {/* Transaction List */}
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <p style={{ color: 'var(--text-muted)', fontSize: 12, marginBottom: 4 }}>
          {filtered.length} transaction{filtered.length !== 1 ? 's' : ''}
        </p>
        {filtered.map((tx) => (
          <TxRow key={tx.id} tx={tx} onClick={() => navigate(`/history/${tx.id}`)} />
        ))}
        {filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text-muted)' }}>
            <p style={{ fontSize: 32, marginBottom: 8 }}>🔍</p>
            <p>No transactions found</p>
          </div>
        )}
      </div>
    </div>
  );
}

function TxRow({ tx, onClick }: { tx: Transaction; onClick: () => void }) {
  const statusColor = { success: '#10b981', failed: '#ef4444', cancelled: '#f59e0b', pending: '#6366f1' }[tx.status];
  const StatusIcon = { success: CheckCircle, failed: XCircle, cancelled: AlertOctagon, pending: Clock }[tx.status];

  return (
    <button
      onClick={onClick}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        background: 'var(--bg-card)',
        border: `1px solid ${tx.isSuspected ? 'rgba(239,68,68,0.2)' : 'var(--border-subtle)'}`,
        borderRadius: 16,
        padding: '12px 16px',
        width: '100%',
        cursor: 'pointer',
        textAlign: 'left',
        fontFamily: 'var(--font-main)',
      }}
    >
      <div
        style={{
          width: 44,
          height: 44,
          borderRadius: 14,
          background: `hsl(${(tx.toName || '?').charCodeAt(0) * 7 % 360}, 40%, 20%)`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 14,
          fontWeight: 700,
          color: `hsl(${(tx.toName || '?').charCodeAt(0) * 7 % 360}, 70%, 65%)`,
          flexShrink: 0,
          position: 'relative',
        }}
      >
        {tx.toName.slice(0, 2).toUpperCase()}
        {tx.isSuspected && (
          <div style={{ position: 'absolute', top: -4, right: -4, width: 14, height: 14, borderRadius: '50%', background: '#ef4444', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <AlertOctagon size={8} color="white" />
          </div>
        )}
      </div>
      <div style={{ flex: 1 }}>
        <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{tx.toName}</p>
        <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>
          {formatDate(tx.timestamp)} · {formatTime(tx.timestamp)}
        </p>
      </div>
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <p style={{ fontSize: 15, fontWeight: 700, color: tx.status === 'success' ? '#f87171' : 'var(--text-muted)' }}>
          {tx.status === 'success' ? '-' : ''}{formatINR(tx.amount)}
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 3, justifyContent: 'flex-end', marginTop: 2 }}>
          <StatusIcon size={11} color={statusColor} />
          <span style={{ color: statusColor, fontSize: 10, fontWeight: 600 }}>{tx.status.toUpperCase()}</span>
        </div>
      </div>
    </button>
  );
}

function buildChartData(transactions: Transaction[]) {
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return { date: d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }), fullDate: d.toDateString(), amount: 0 };
  });

  transactions.forEach((tx) => {
    if (tx.status !== 'success') return;
    const txDate = new Date(tx.timestamp).toDateString();
    const day = days.find((d) => d.fullDate === txDate);
    if (day) day.amount += tx.amount;
  });

  return days;
}
