import { useNavigate, useParams } from 'react-router-dom';
import { useTransactionStore } from '@/stores/transactionStore';
import { useTrustStore } from '@/stores/trustStore';
import { useUserStore } from '@/stores/userStore';
import { formatINR, formatDateTime, getTrustColor } from '@/utils';
import {
  ArrowLeft, CheckCircle, XCircle, AlertOctagon, Shield,
  Flag, Clock, CreditCard
} from 'lucide-react';
import { useState } from 'react';

import { useAuthStore } from '@/stores/authStore';

export default function TransactionDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { transactions } = useTransactionStore();
  const { addFlag, getFlagsInLast30Days } = useTrustStore();
  const { updateTrustScore, suspendAccount, accounts } = useUserStore();
  const { currentUserId } = useAuthStore();
  const [reported, setReported] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);

  const currentUser = accounts.find(a => a.id === currentUserId);
  const tx = transactions.find((t) => t.id === id);

  if (!tx) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', flexDirection: 'column', gap: 16 }}>
        <p style={{ color: 'var(--text-muted)', fontSize: 16 }}>Transaction not found</p>
        <button className="btn btn-secondary" onClick={() => navigate('/history')}>Go Back</button>
      </div>
    );
  }

  const statusColor = { success: '#10b981', failed: '#ef4444', cancelled: '#f59e0b', pending: '#6366f1' }[tx.status];
  const StatusIcon = { success: CheckCircle, failed: XCircle, cancelled: AlertOctagon, pending: Clock }[tx.status];
  const tColor = getTrustColor(tx.trustScoreAtTime);

  const handleReport = () => {
    if (reported || !currentUser) return;
    
    const receiverId = tx.toUserId;
    if (receiverId) {
      addFlag({ id: `flag-${Date.now()}`, userId: receiverId, reason: `Fraud reported by user on transaction ${tx.id}`, timestamp: new Date().toISOString(), triggeredBy: 'report', transactionId: tx.id });
      const newFlagsCount = getFlagsInLast30Days(receiverId).length;
      
      const receiverAcc = accounts.find(a => a.id === receiverId);
      if (receiverAcc) {
          const penalty = Number(import.meta.env.VITE_TRUST_SCORE_PENALTY) || 20;
          const threshold = Number(import.meta.env.VITE_FRAUD_SUSPENSION_THRESHOLD) || 2;
          const newScore = Math.max(0, receiverAcc.trustScore - penalty);
          updateTrustScore(receiverId, newScore);
          if (newFlagsCount >= threshold) suspendAccount(receiverId);
      }
    } else {
        const extId = tx.toUpiId || 'external';
        addFlag({ id: `flag-${Date.now()}`, userId: extId, reason: `Fraud reported by user on transaction ${tx.id}`, timestamp: new Date().toISOString(), triggeredBy: 'report', transactionId: tx.id });
    }
    
    setReported(true);
    setShowReportModal(false);
  };

  const methodLabel = { qr: 'QR Code', contact: 'Contact', mobile: 'Mobile Number', bank: 'Bank Transfer' }[tx.method];
  const methodIcon = { qr: '📷', contact: '👥', mobile: '📱', bank: '🏦' }[tx.method];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', padding: '50px 0 0' }}>
      {/* Header */}
      <div style={{ padding: '0 20px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => navigate('/history')} style={{ background: 'var(--bg-card)', border: '1px solid var(--border-subtle)', borderRadius: 12, padding: 8, cursor: 'pointer', color: 'var(--text-primary)' }}>
          <ArrowLeft size={18} />
        </button>
        <h1 style={{ fontSize: 20, fontWeight: 700 }}>Transaction Detail</h1>
      </div>

      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Status Banner */}
        <div
          style={{
            background: `${statusColor}12`,
            border: `1px solid ${statusColor}30`,
            borderRadius: 24,
            padding: '28px 24px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 12,
          }}
        >
          <div style={{ width: 64, height: 64, borderRadius: '50%', background: `${statusColor}15`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <StatusIcon size={30} color={statusColor} />
          </div>
          <div style={{ textAlign: 'center' }}>
            <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginBottom: 4 }}>
              {tx.status === 'success' ? 'Sent to' : 'Attempted to'} {tx.toName}
            </p>
            <p style={{ fontSize: 36, fontWeight: 900, color: statusColor, letterSpacing: '-1px' }}>
              {formatINR(tx.amount)}
            </p>
            <p style={{ color: statusColor, fontSize: 12, fontWeight: 600, marginTop: 4 }}>
              {tx.status.toUpperCase()}
            </p>
          </div>
        </div>

        {/* Fraud flag */}
        {tx.isSuspected && (
          <div style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', borderRadius: 16, padding: '12px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <AlertOctagon size={16} color="#ef4444" />
              <p style={{ color: '#ef4444', fontSize: 13, fontWeight: 700 }}>Flagged as Suspicious</p>
            </div>
            {tx.fraudFlags.map((f, i) => (
              <p key={i} style={{ color: 'rgba(239,68,68,0.7)', fontSize: 12, marginBottom: 2 }}>• {f}</p>
            ))}
          </div>
        )}

        {/* Details Grid */}
        <div style={{ background: 'var(--bg-card)', borderRadius: 20, border: '1px solid var(--border-subtle)', overflow: 'hidden' }}>
          {[
            { label: 'Recipient', value: tx.toName },
            { label: 'UPI / Account', value: tx.toUpiId },
            { label: 'Date & Time', value: formatDateTime(tx.timestamp) },
            { label: 'Method', value: `${methodIcon} ${methodLabel}` },
            { label: 'Transaction ID', value: tx.id, mono: true },
            ...(tx.note ? [{ label: 'Note', value: tx.note }] : []),
          ].map(({ label, value, mono }, i, arr) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 16px', borderBottom: i < arr.length - 1 ? '1px solid var(--border-subtle)' : 'none' }}>
              <span style={{ color: 'var(--text-muted)', fontSize: 13 }}>{label}</span>
              <span style={{ color: 'var(--text-primary)', fontSize: 13, fontWeight: 600, fontFamily: mono ? 'monospace' : 'inherit', maxWidth: '60%', textAlign: 'right', wordBreak: 'break-all' }}>
                {value}
              </span>
            </div>
          ))}
        </div>

        {/* Trust at time */}
        <div style={{ background: 'var(--bg-card)', borderRadius: 18, padding: '14px 16px', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <Shield size={18} color={tColor} />
          <div>
            <p style={{ color: 'var(--text-secondary)', fontSize: 12 }}>Trust Score at transaction time</p>
            <p style={{ color: tColor, fontSize: 16, fontWeight: 700 }}>{tx.trustScoreAtTime}%</p>
          </div>
        </div>

        {/* Report Fraud Button */}
        {tx.status === 'success' && !reported && !tx.isSuspected && (
          <button
            onClick={() => setShowReportModal(true)}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 16, padding: '14px', cursor: 'pointer', color: '#ef4444', fontFamily: 'var(--font-main)', fontSize: 14, fontWeight: 600 }}
          >
            <Flag size={16} /> Report as Fraud
          </button>
        )}
        {reported && (
          <div style={{ textAlign: 'center', padding: '12px', color: '#f59e0b', fontSize: 13, fontWeight: 600 }}>
            ✓ Fraud report submitted. Trust score updated.
          </div>
        )}
      </div>

      {/* Report Modal */}
      {showReportModal && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', zIndex: 100, padding: '0 16px 20px' }}
          onClick={() => setShowReportModal(false)}
        >
          <div
            style={{ background: 'var(--bg-card)', border: '1px solid var(--border-main)', borderRadius: 24, padding: 24, width: '100%', maxWidth: 400 }}
            onClick={(e) => e.stopPropagation()}
          >
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8, textAlign: 'center' }}>Report Transaction?</h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: 13, textAlign: 'center', marginBottom: 20 }}>
              Reporting will reduce the recipient's Trust Score by 20%. This action cannot be undone.
            </p>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => setShowReportModal(false)}>Cancel</button>
              <button className="btn btn-danger" style={{ flex: 1 }} onClick={handleReport}>Report Fraud</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
