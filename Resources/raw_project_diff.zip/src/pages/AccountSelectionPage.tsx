import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserStore } from '@/stores/userStore';
import { Shield, User, Settings } from 'lucide-react';

export default function AccountSelectionPage() {
  const navigate = useNavigate();
  const { accounts } = useUserStore();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const handleContinue = () => {
    if (selectedId) {
      navigate(`/login/${selectedId}`);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
      
      {/* Admin Button */}
      <button 
        onClick={() => navigate('/admin')}
        style={{ position: 'absolute', top: 20, right: 20, background: 'rgba(255,255,255,0.05)', border: '1px solid var(--border-subtle)', borderRadius: 12, padding: 10, cursor: 'pointer', color: 'var(--text-secondary)' }}
      >
        <Settings size={20} />
      </button>

      <div style={{ width: 80, height: 80, borderRadius: 24, background: 'linear-gradient(135deg, #6366f1, #a855f7, #ec4899)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 32, boxShadow: '0 12px 30px rgba(99,102,241,0.3)' }}>
        <Shield size={40} color="white" />
      </div>

      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 8, textAlign: 'center' }}>SecurePay Demo</h1>
      <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginBottom: 40, textAlign: 'center', maxWidth: 280 }}>
        Select a test account to log in. You can switch accounts later to demo sending/receiving.
      </p>

      <div style={{ width: '100%', maxWidth: 360, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {accounts.map((acc) => (
          <button
            key={acc.id}
            onClick={() => setSelectedId(acc.id)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 16,
              background: selectedId === acc.id ? 'rgba(99,102,241,0.15)' : 'var(--bg-card)',
              border: `2px solid ${selectedId === acc.id ? '#6366f1' : 'var(--border-subtle)'}`,
              borderRadius: 20,
              padding: '16px',
              cursor: 'pointer',
              textAlign: 'left',
              transition: 'all 0.2s',
            }}
          >
            <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <User size={20} color={selectedId === acc.id ? '#6366f1' : 'var(--text-secondary)'} />
            </div>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 2 }}>{acc.name}</p>
              <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>{acc.upiId}</p>
            </div>
            {acc.isSuspended && (
              <span style={{ fontSize: 10, fontWeight: 800, background: 'rgba(239,68,68,0.15)', color: '#ef4444', padding: '4px 8px', borderRadius: 8, textTransform: 'uppercase' }}>
                Suspended
              </span>
            )}
          </button>
        ))}
      </div>

      <button 
        className="btn btn-primary" 
        style={{ width: '100%', maxWidth: 360, marginTop: 32, opacity: selectedId ? 1 : 0.5, pointerEvents: selectedId ? 'auto' : 'none' }}
        onClick={handleContinue}
        disabled={!selectedId}
      >
        Continue
      </button>

    </div>
  );
}
