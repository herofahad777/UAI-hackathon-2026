import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserStore } from '@/stores/userStore';
import { useTrustStore } from '@/stores/trustStore';
import { useAuthStore } from '@/stores/authStore';
import { useTransactionStore } from '@/stores/transactionStore';
import {
  Shield, QrCode, Users, Phone, Building2,
  Clock, Sparkles, AlertTriangle, LogOut, ChevronRight, TrendingUp, X
} from 'lucide-react';
import { formatINR, getTrustColor, getTrustLabel } from '@/utils';
import QRCode from 'react-qr-code';

const QUICK_ACTIONS = [
  { icon: QrCode, label: 'Scan QR', path: '/pay/qr', color: '#6366f1', bg: 'rgba(99,102,241,0.15)' },
  { icon: Users, label: 'Contacts', path: '/pay/contact', color: '#8b5cf6', bg: 'rgba(139,92,246,0.15)' },
  { icon: Phone, label: 'Mobile', path: '/pay/mobile', color: '#06b6d4', bg: 'rgba(6,182,212,0.15)' },
  { icon: Building2, label: 'Bank', path: '/pay/bank', color: '#10b981', bg: 'rgba(16,185,129,0.15)' },
  { icon: Clock, label: 'History', path: '/history', color: '#f59e0b', bg: 'rgba(245,158,11,0.15)' },
  { icon: Sparkles, label: 'AI Advisor', path: '/advisor', color: '#ec4899', bg: 'rgba(236,72,153,0.15)' },
  { icon: AlertTriangle, label: 'Emergency', path: '/emergency', color: '#ef4444', bg: 'rgba(239,68,68,0.15)' },
];

export default function Dashboard() {
  const navigate = useNavigate();
  const { currentUserId, logout } = useAuthStore();
  const { accounts } = useUserStore();
  const { getFlagsInLast30Days } = useTrustStore();
  
  const currentUser = accounts.find(a => a.id === currentUserId);
  const flags = currentUser ? getFlagsInLast30Days(currentUser.id) : [];
  const [showQr, setShowQr] = useState(false);

  if (!currentUser) return null;

  const trustColor = getTrustColor(currentUser.trustScore);
  const trustLabel = getTrustLabel(currentUser.trustScore);

  // SVG circle calculation
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference - (circumference * currentUser.trustScore) / 100;

  const upiPayString = `upi://pay?pa=${currentUser.upiId}&pn=${encodeURIComponent(currentUser.name)}&cu=INR`;

  const timeOfDay = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <div
      style={{
        padding: '0 0 16px',
        minHeight: '100vh',
        background: 'var(--bg-primary)',
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: '50px 24px 24px',
          background: 'linear-gradient(180deg, #12121f 0%, transparent 100%)',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 4 }}>
              {timeOfDay()} 👋
            </p>
            <h2 style={{ fontSize: 20, fontWeight: 700 }}>{currentUser.name}</h2>
            <p style={{ color: 'var(--text-muted)', fontSize: 12, marginTop: 2 }}>
              {currentUser.upiId}
            </p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={() => setShowQr(true)}
              style={{
                background: 'rgba(99,102,241,0.15)',
                border: '1px solid rgba(99,102,241,0.3)',
                borderRadius: 12,
                padding: '8px 12px',
                color: '#6366f1',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                fontSize: 13,
                fontWeight: 600,
              }}
            >
              <QrCode size={18} />
              Receive
            </button>
            <button
              onClick={() => { logout(); navigate('/'); }}
              style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: 12,
                padding: '8px 12px',
                color: 'var(--text-secondary)',
                cursor: 'pointer',
              }}
            >
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* QR Modal */}
      {showQr && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(8px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: 'var(--bg-card)', borderRadius: 28, padding: 32, width: '100%', maxWidth: 360, position: 'relative', border: '1px solid var(--border-main)', textAlign: 'center' }}>
            <button onClick={() => setShowQr(false)} style={{ position: 'absolute', top: 16, right: 16, background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
              <X size={24} />
            </button>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>My QR Code</h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 24 }}>Scan this to pay me via SecurePay</p>
            
            <div style={{ background: 'white', padding: 16, borderRadius: 20, display: 'inline-block', boxShadow: '0 0 40px rgba(99,102,241,0.2)' }}>
              <QRCode value={upiPayString} size={200} />
            </div>
            
            <div style={{ marginTop: 24, textAlign: 'center' }}>
              <p style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)' }}>{currentUser.name}</p>
              <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>{currentUser.upiId}</p>
            </div>
          </div>
        </div>
      )}

      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Balance + Trust Card */}
        <div
          style={{
            background: 'linear-gradient(135deg, #1a1a3e 0%, #1e1e3f 100%)',
            borderRadius: 24,
            padding: '24px',
            border: '1px solid rgba(99,102,241,0.2)',
            boxShadow: '0 8px 32px rgba(99,102,241,0.1)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          {/* Balance */}
          <div>
            <p style={{ color: 'var(--text-muted)', fontSize: 12, marginBottom: 8 }}>
              Available Balance
            </p>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: 18 }}>₹</span>
              <span style={{ fontSize: 32, fontWeight: 800, letterSpacing: '-1px' }}>
                {currentUser.balance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </span>
            </div>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4,
                background: 'rgba(16,185,129,0.1)',
                border: '1px solid rgba(16,185,129,0.2)',
                borderRadius: 8,
                padding: '3px 8px',
                marginTop: 8,
              }}
            >
              <TrendingUp size={12} color="#10b981" />
              <span style={{ color: '#10b981', fontSize: 11, fontWeight: 600 }}>
                +2.3% this month
              </span>
            </div>
          </div>

          {/* Trust Score SVG Circle */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
            <svg width={130} height={130} style={{ transform: 'rotate(-90deg)' }}>
              {/* Background track */}
              <circle cx={65} cy={65} r={radius} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={8} />
              {/* Progress */}
              <circle
                cx={65}
                cy={65}
                r={radius}
                fill="none"
                stroke={trustColor}
                strokeWidth={8}
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={dashOffset}
                style={{ transition: 'stroke-dashoffset 0.8s ease, stroke 0.3s ease' }}
              />
            </svg>
            {/* Center text – absolutely positioned over SVG */}
            <div
              style={{
                position: 'relative',
                marginTop: -105,
                width: 130,
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 22, fontWeight: 800, color: trustColor, lineHeight: 1 }}>
                {currentUser.trustScore}%
              </div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 4 }}>
                Trust
              </div>
              <Shield size={12} color={trustColor} style={{ margin: '2px auto 0', display: 'block' }} />
            </div>
            <span style={{ fontSize: 10, color: trustColor, fontWeight: 600, marginTop: 30 }}>
              {trustLabel}
            </span>
          </div>
        </div>

        {/* Fraud flags warning */}
        {flags.length > 0 && (
          <div
            style={{
              background: 'rgba(239,68,68,0.1)',
              border: '1px solid rgba(239,68,68,0.25)',
              borderRadius: 16,
              padding: '12px 16px',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
            }}
          >
            <AlertTriangle size={18} color="#ef4444" />
            <div style={{ flex: 1 }}>
              <p style={{ color: '#ef4444', fontSize: 13, fontWeight: 600 }}>
                {flags.length} fraud flag{flags.length > 1 ? 's' : ''} on your account
              </p>
              <p style={{ color: 'rgba(239,68,68,0.7)', fontSize: 11, marginTop: 2 }}>
                Trust score reduced. {flags.length >= 2 ? 'Account at risk of suspension.' : ''}
              </p>
            </div>
            <ChevronRight size={16} color="#ef4444" />
          </div>
        )}

        {/* Quick Actions Grid */}
        <div>
          <p style={{ color: 'var(--text-secondary)', fontSize: 12, fontWeight: 600, marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.8px' }}>
            Quick Actions
          </p>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(4, 1fr)',
              gap: 12,
            }}
          >
            {QUICK_ACTIONS.map(({ icon: Icon, label, path, color, bg }) => (
              <button
                key={path}
                onClick={() => navigate(path)}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 8,
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: 18,
                  padding: '14px 8px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  fontFamily: 'var(--font-main)',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = color;
                  (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border-subtle)';
                  (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
                }}
              >
                <div
                  style={{
                    width: 44,
                    height: 44,
                    background: bg,
                    borderRadius: 14,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon size={20} color={color} />
                </div>
                <span style={{ color: 'var(--text-secondary)', fontSize: 10, fontWeight: 600, textAlign: 'center', lineHeight: 1.2 }}>
                  {label}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Transactions Preview */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <p style={{ color: 'var(--text-secondary)', fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.8px' }}>
              Recent
            </p>
            <button
              onClick={() => navigate('/history')}
              style={{ background: 'none', border: 'none', color: '#6366f1', fontSize: 12, cursor: 'pointer', fontFamily: 'var(--font-main)', fontWeight: 600 }}
            >
              View all →
            </button>
          </div>
          <RecentTransactions />
        </div>
      </div>
    </div>
  );
}

function RecentTransactions() {
  const navigate = useNavigate();
  const { currentUserId } = useAuthStore();
  const { getUserTransactions } = useTransactionStore();
  const recent = currentUserId ? getUserTransactions(currentUserId).slice(0, 3) : [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {recent.map((tx) => (
        <button
          key={tx.id}
          onClick={() => navigate(`/history/${tx.id}`)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            background: 'var(--bg-card)',
            border: '1px solid var(--border-subtle)',
            borderRadius: 16,
            padding: '12px 16px',
            width: '100%',
            cursor: 'pointer',
            textAlign: 'left',
            fontFamily: 'var(--font-main)',
          }}
        >
          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: 12,
              background: `hsl(${(tx.toName || '?').charCodeAt(0) * 7 % 360}, 50%, 25%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 14,
              fontWeight: 700,
              color: `hsl(${(tx.toName || '?').charCodeAt(0) * 7 % 360}, 80%, 70%)`,
              flexShrink: 0,
            }}
          >
            {tx.toName.slice(0, 2).toUpperCase()}
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{tx.toName}</p>
            <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>
              {new Date(tx.timestamp).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
            </p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{
              fontSize: 15,
              fontWeight: 700,
              color: tx.status === 'success' ? '#ef4444' : 'var(--text-muted)',
            }}>
              {tx.status === 'success' ? '-' : ''}{formatINR(tx.amount)}
            </p>
            <span style={{
              fontSize: 10,
              fontWeight: 600,
              color: tx.status === 'success' ? '#10b981' : tx.status === 'failed' ? '#ef4444' : '#f59e0b',
            }}>
              {tx.status.toUpperCase()}
            </span>
          </div>
        </button>
      ))}
    </div>
  );
}

// End of Dashboard

