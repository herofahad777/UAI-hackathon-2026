import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useUserStore } from '@/stores/userStore';
import { useAuthStore } from '@/stores/authStore';
import { useTrustStore } from '@/stores/trustStore';
import { useTransactionStore } from '@/stores/transactionStore';
import { detectFraud, calculateNewTrustScore, shouldSuspendAccount } from '@/services/fraudEngine';
import { formatINR, getTrustColor, generateTxId, getInitials, getAvatarColor } from '@/utils';
import {
  QrCode, Users, Phone, Building2, ArrowLeft,
  Search, CheckCircle, XCircle, AlertTriangle,
  Shield, ChevronRight, Banknote
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Transaction, Contact } from '@/types';

type PaymentMethod = 'qr' | 'contact' | 'mobile' | 'bank';

const METHODS: { key: PaymentMethod; icon: typeof QrCode; label: string; color: string }[] = [
  { key: 'qr', icon: QrCode, label: 'Scan QR', color: '#6366f1' },
  { key: 'contact', icon: Users, label: 'Contacts', color: '#8b5cf6' },
  { key: 'mobile', icon: Phone, label: 'Mobile', color: '#06b6d4' },
  { key: 'bank', icon: Building2, label: 'Bank', color: '#10b981' },
];

/* ─── Zod Schemas ─────────────────────────────────────── */
const mobileSchema = z.object({
  phone: z.string().regex(/^[6-9]\d{9}$/, 'Enter a valid 10-digit mobile number'),
  amount: z.coerce.number().min(1, 'Minimum ₹1').max(200000, 'Maximum ₹2,00,000'),
  note: z.string().optional(),
});
const bankSchema = z.object({
  accountNumber: z.string().min(9, 'Min 9 digits').max(18, 'Max 18 digits'),
  ifsc: z.string().regex(/^[A-Z]{4}0[A-Z0-9]{6}$/, 'Invalid IFSC code'),
  holderName: z.string().min(2, 'Enter name'),
  amount: z.coerce.number().min(1, 'Minimum ₹1').max(200000, 'Maximum ₹2,00,000'),
  note: z.string().optional(),
});

type MobileForm = z.infer<typeof mobileSchema>;
type BankForm = z.infer<typeof bankSchema>;

/* ─── Main Component ──────────────────────────────────── */
export default function PaymentPage() {
  const { method: paramMethod } = useParams<{ method?: string }>();
  const [active, setActive] = useState<PaymentMethod>((paramMethod as PaymentMethod) || 'contact');
  const [txState, setTxState] = useState<'idle' | 'fraud-alert' | 'processing' | 'success' | 'failed'>('idle');
  const [pendingTx, setPendingTx] = useState<Partial<Transaction> | null>(null);
  const [fraudReasons, setFraudReasons] = useState<string[]>([]);
  const [processingCountdown, setProcessingCountdown] = useState(8);
  const [paused, setPaused] = useState(false);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const navigate = useNavigate();

  const { currentUserId } = useAuthStore();
  const { accounts, deductBalance, addBalance, suspendAccount, updateTrustScore } = useUserStore();
  const currentUser = accounts.find(a => a.id === currentUserId);
  const { addFlag } = useTrustStore();
  const { transactions, addTransaction, getRecentTransactions } = useTransactionStore();

  useEffect(() => {
    if (paramMethod && ['qr','contact','mobile','bank'].includes(paramMethod)) {
      setActive(paramMethod as PaymentMethod);
    }
  }, [paramMethod]);

  /* Start processing countdown */
  const startProcessing = (tx: Partial<Transaction>) => {
    setTxState('processing');
    setPendingTx(tx);
    setProcessingCountdown(8);
    setPaused(false);
    let remaining = 8;
    countdownRef.current = setInterval(() => {
      if (!paused) {
        remaining -= 1;
        setProcessingCountdown(remaining);
        if (remaining <= 0) {
          clearInterval(countdownRef.current!);
          commitTransaction(tx, true);
        }
      }
    }, 1000);
  };

  /* Commit transaction to store */
  const commitTransaction = (tx: Partial<Transaction>, wasBig: boolean) => {
    if (!currentUser) return;
    
    const amount = Number(tx.amount) || 0;
    
    const fullTx: Transaction = {
      id: generateTxId(),
      fromUserId: currentUser.id,
      toUserId: tx.toUserId || '',
      toName: tx.toName || 'Unknown',
      toUpiId: tx.toUpiId || '',
      amount: amount,
      method: tx.method || 'mobile',
      status: 'success',
      timestamp: new Date().toISOString(),
      trustScoreAtTime: currentUser.trustScore,
      isSuspected: fraudReasons.length > 0,
      fraudFlags: [...fraudReasons],
      note: tx.note || '',
    };

    addTransaction(fullTx);
    deductBalance(currentUser.id, amount);
    
    if (fullTx.toUserId) {
      addBalance(fullTx.toUserId, amount);
    }

    setPendingTx(fullTx);
    setTxState('success');
  };

  /* Handle payment initiation */
  const initiatePay = (tx: Partial<Transaction>) => {
    if (!currentUser) return;

    // Lookup toUserId if missing (e.g. from QR scan)
    let finalTx = { ...tx };
    if (!finalTx.toUserId && finalTx.toUpiId) {
      const recipient = accounts.find(a => a.upiId === finalTx.toUpiId);
      if (recipient) {
        finalTx.toUserId = recipient.id;
        finalTx.toName = recipient.name; // Use official name from store
      }
    }

    const recent = getRecentTransactions(currentUser.id, 10);
    const userTransactions = transactions.filter(t => t.fromUserId === currentUser.id);
    const result = detectFraud(finalTx.amount || 0, recent, userTransactions);

    if (result.isFraud) {
      setFraudReasons(result.reasons);
      setPendingTx(finalTx);
      setTxState('fraud-alert');
    } else {
      if ((finalTx.amount || 0) >= 10000) {
        startProcessing(finalTx);
      } else {
        commitTransaction(finalTx, false);
        // Note: commitTransaction already calls setTxState('success') and setPendingTx(fullTx)
      }
    }
  };

  /* Proceed after fraud warning */
  const proceedAnyway = () => {
    if (!currentUser) return;

    // The user (sender) is proceeding despite the warning.
    // The recipient will be flagged and penalized.
    // If the recipient is an internal test account, apply the penalty to them directly.
    const receiverId = pendingTx?.toUserId;

    if (receiverId) {
      addFlag({ id: generateTxId(), userId: receiverId, reason: fraudReasons[0], timestamp: new Date().toISOString(), triggeredBy: 'auto' });
      const { accounts } = useUserStore.getState();
      const receiverAcc = accounts.find(a => a.id === receiverId);
      
      if (receiverAcc) {
        const flagsCount = useTrustStore.getState().getFlagsInLast30Days(receiverId).length;
        const newScore = calculateNewTrustScore(receiverAcc.trustScore, flagsCount);
        updateTrustScore(receiverId, newScore);
        if (shouldSuspendAccount(flagsCount)) {
          suspendAccount(receiverId);
        }
      }
    } else {
      // If external user, we just add the flag to the system with their upi/name as identifier if needed.
      // We will associate the flag with an external pseudo-ID
      const extId = pendingTx?.toUpiId || 'external';
      addFlag({ id: generateTxId(), userId: extId, reason: fraudReasons[0], timestamp: new Date().toISOString(), triggeredBy: 'auto' });
    }

    if ((pendingTx?.amount || 0) >= 10000) {
      startProcessing(pendingTx!);
    } else {
      commitTransaction(pendingTx!, false);
    }
  };

  /* Processing – Pause */
  const handlePause = () => {
    setPaused(true);
    clearInterval(countdownRef.current!);
  };

  /* Processing – Cancel */
  const handleCancel = () => {
    clearInterval(countdownRef.current!);
    setTxState('failed');
  };

  /* Processing – Resume */
  const handleResume = () => {
    setPaused(false);
    let remaining = processingCountdown;
    countdownRef.current = setInterval(() => {
      remaining -= 1;
      setProcessingCountdown(remaining);
      if (remaining <= 0) {
        clearInterval(countdownRef.current!);
        commitTransaction(pendingTx!, true);
      }
    }, 1000);
  };

  /* ─── Overlay States ──────────────────────────────────────── */
  if (txState === 'fraud-alert') {
    return (
      <FraudAlertOverlay
        reasons={fraudReasons}
        amount={pendingTx?.amount || 0}
        toName={pendingTx?.toName || ''}
        onProceed={proceedAnyway}
        onCancel={() => setTxState('idle')}
      />
    );
  }

  if (txState === 'processing') {
    return (
      <div style={{ position: 'fixed', inset: 0, zIndex: 3000 }}>
        <ProcessingScreen
          amount={pendingTx?.amount || 0}
          toName={pendingTx?.toName || ''}
          countdown={processingCountdown}
          paused={paused}
          onPause={handlePause}
          onResume={handleResume}
          onCancel={handleCancel}
        />
      </div>
    );
  }

  if (txState === 'success' || txState === 'failed') {
    return (
      <div style={{ position: 'fixed', inset: 0, zIndex: 4000 }}>
        <ResultScreen
          status={txState}
          tx={pendingTx}
          onDone={() => navigate('/dashboard')}
        />
      </div>
    );
  }

  return (
    <div style={{ padding: '50px 0 0', minHeight: '100vh', background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div style={{ padding: '0 20px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button
          onClick={() => navigate(-1)}
          style={{ background: 'var(--bg-card)', border: '1px solid var(--border-subtle)', borderRadius: 12, padding: 8, cursor: 'pointer', color: 'var(--text-primary)' }}
        >
          <ArrowLeft size={18} />
        </button>
        <h1 style={{ fontSize: 20, fontWeight: 700 }}>Make Payment</h1>
      </div>

      {/* Method Tabs */}
      <div style={{ display: 'flex', padding: '0 16px', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
        {METHODS.map(({ key, icon: Icon, label, color }) => (
          <button
            key={key}
            onClick={() => setActive(key)}
            style={{
              flexShrink: 0,
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '8px 14px',
              borderRadius: 12,
              border: '1px solid',
              borderColor: active === key ? color : 'var(--border-subtle)',
              background: active === key ? `${color}15` : 'var(--bg-card)',
              color: active === key ? color : 'var(--text-secondary)',
              fontSize: 13,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'var(--font-main)',
              transition: 'all 0.2s',
            }}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

      <div style={{ padding: '16px 16px 0' }}>
        {active === 'qr' && <QRView onPay={initiatePay} />}
        {active === 'contact' && <ContactView onPay={initiatePay} />}
        {active === 'mobile' && <MobileView onPay={initiatePay} />}
        {active === 'bank' && <BankView onPay={initiatePay} />}
      </div>
    </div>
  );
}

/* ─── QR Scanner View ─────────────────────────────────── */
function QRView({ onPay }: { onPay: (tx: Partial<Transaction>) => void }) {
  const [scanning, setScanning] = useState(false);
  const [qrData, setQrData] = useState<{ upiId: string; name: string } | null>(null);
  const [amount, setAmount] = useState('');
  const divRef = useRef<HTMLDivElement>(null);
  const scannerRef = useRef<any>(null);
  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        scannerRef.current.stop().catch(() => {});
      }
    };
  }, []);

  const startScan = async () => {
    if (scanning) return;
    setScanning(true);
    try {
      const { Html5Qrcode } = await import('html5-qrcode');
      if (!scannerRef.current) {
        scannerRef.current = new Html5Qrcode('qr-reader');
      }
      
      await scannerRef.current.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        (text: string) => {
          // Parse UPI QR: upi://pay?pa=upiId&pn=Name&am=amount
          const urlString = text.includes('?') ? text : `?pa=${text}`;
          const params = new URLSearchParams(urlString.split('?')[1] || '');
          const upiId = params.get('pa') || text;
          const name = params.get('pn') || 'Merchant';
          const am = params.get('am') || '';
          
          if (scannerRef.current) {
            scannerRef.current.stop().then(() => {
              setScanning(false);
              setQrData({ upiId, name });
              if (am) setAmount(am);
            }).catch((err: any) => {
              console.error('Stop error:', err);
              setScanning(false);
              setQrData({ upiId, name });
              if (am) setAmount(am);
            });
          }
        },
        () => {}
      );
    } catch (e) {
      console.error('Scan error:', e);
      setScanning(false);
    }
  };

  const stopScan = async () => {
    if (scannerRef.current) {
      try {
        await scannerRef.current.stop();
      } catch (e) {}
    }
    setScanning(false);
  };

  if (qrData) {
    return (
      <PayConfirmCard
        name={qrData.name}
        upiId={qrData.upiId}
        amount={amount}
        setAmount={setAmount}
        onPay={() => onPay({ toName: qrData.name, toUpiId: qrData.upiId, amount: parseFloat(amount), method: 'qr' })}
        onBack={() => setQrData(null)}
      />
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 24, padding: '20px 0' }}>
      <div
        style={{
          width: '100%',
          aspectRatio: '1',
          background: 'var(--bg-card)',
          borderRadius: 24,
          border: '2px dashed var(--border-main)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 12,
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <div id="qr-reader" ref={divRef} style={{ width: '100%', borderRadius: 20 }} />
        {!scanning && (
          <>
            <QrCode size={60} color="var(--text-muted)" />
            <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Camera will open here</p>
          </>
        )}
      </div>
      {!scanning ? (
        <button className="btn btn-primary" style={{ width: '100%' }} onClick={startScan}>
          <QrCode size={18} /> Start Camera Scan
        </button>
      ) : (
        <button className="btn btn-secondary" style={{ width: '100%' }} onClick={stopScan}>
          Stop Scanning
        </button>
      )}
      <p style={{ color: 'var(--text-muted)', fontSize: 12, textAlign: 'center' }}>
        Scan any UPI-enabled QR code to auto-fill payment details
      </p>
    </div>
  );
}

/* ─── Contact View ────────────────────────────────────── */
function ContactView({ onPay }: { onPay: (tx: Partial<Transaction>) => void }) {
  const contacts = useUserStore((s) => s.contacts);
  const { currentUserId } = useAuthStore();
  const accounts = useUserStore((s) => s.accounts);
  const currentUser = accounts.find(a => a.id === currentUserId);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Contact | null>(null);
  const [amount, setAmount] = useState('');

  const allContacts: Contact[] = [
    ...contacts,
    ...accounts
      .filter(a => a.id !== currentUserId)
      .map(a => ({
        id: a.id,
        name: a.name,
        phone: a.phone,
        upiId: a.upiId
      }))
  ];

  const filtered = allContacts.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search) ||
      c.upiId.toLowerCase().includes(search.toLowerCase())
  );

  if (selected) {
    return (
      <PayConfirmCard
        name={selected.name}
        upiId={selected.upiId}
        amount={amount}
        setAmount={setAmount}
        trustScore={currentUser?.trustScore || 100}
        onPay={() => onPay({ toName: selected.name, toUpiId: selected.upiId, toUserId: selected.id, amount: parseFloat(amount), method: 'contact' })}
        onBack={() => setSelected(null)}
      />
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ position: 'relative' }}>
        <Search size={16} style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        <input
          className="input"
          placeholder="Search by name, phone or UPI ID"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ paddingLeft: 40 }}
        />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {filtered.map((c) => (
          <button
            key={c.id}
            onClick={() => setSelected(c)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              padding: '12px 16px',
              background: 'var(--bg-card)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 16,
              cursor: 'pointer',
              width: '100%',
              textAlign: 'left',
              fontFamily: 'var(--font-main)',
              transition: 'border-color 0.2s',
            }}
          >
            <div
              style={{
                width: 44,
                height: 44,
                borderRadius: 14,
                background: getAvatarColor(c.name) + '20',
                border: `1px solid ${getAvatarColor(c.name)}40`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: getAvatarColor(c.name),
                fontWeight: 700,
                fontSize: 15,
                flexShrink: 0,
              }}
            >
              {getInitials(c.name)}
            </div>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{c.name}</p>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{c.upiId}</p>
                <span style={{ fontSize: 10, color: 'var(--text-muted)', opacity: 0.5 }}>•</span>
                <p style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{c.phone}</p>
              </div>
            </div>
            {c.recentAmount && (
              <div style={{ textAlign: 'right' }}>
                <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Recent</p>
                <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>{formatINR(c.recentAmount)}</p>
              </div>
            )}
            <ChevronRight size={16} color="var(--text-muted)" />
          </button>
        ))}
      </div>
    </div>
  );
}

/* ─── Mobile View ─────────────────────────────────────── */
function MobileView({ onPay }: { onPay: (tx: Partial<Transaction>) => void }) {
  const { register, handleSubmit, watch, formState: { errors } } = useForm<MobileForm>({ resolver: zodResolver(mobileSchema) });
  const phone = watch('phone', '');
  const upiSuffix = ['@okicici', '@ybl', '@paytm', '@okaxis', '@upi'];
  const suggestedUpi = phone.length === 10 ? `${phone}${upiSuffix[phone.charCodeAt(9) % upiSuffix.length]}` : '';

  const onSubmit = (data: MobileForm) => {
    onPay({ toName: `+91 ${data.phone}`, toUpiId: suggestedUpi, amount: data.amount, method: 'mobile', note: data.note });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div>
        <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Mobile Number</label>
        <input className="input" placeholder="Enter 10-digit mobile number" {...register('phone')} maxLength={10} />
        {errors.phone && <p style={{ color: '#ef4444', fontSize: 11, marginTop: 4 }}>{errors.phone.message}</p>}
        {suggestedUpi && (
          <p style={{ color: '#6366f1', fontSize: 12, marginTop: 6 }}>
            Suggested UPI: <strong>{suggestedUpi}</strong>
          </p>
        )}
      </div>
      <AmountField register={register} error={errors.amount?.message} />
      <div>
        <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Note (Optional)</label>
        <input className="input" placeholder="What's this for?" {...register('note')} />
      </div>
      <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: 8 }}>
        <Phone size={18} /> Pay Now
      </button>
    </form>
  );
}

/* ─── Bank Transfer View ──────────────────────────────── */
function BankView({ onPay }: { onPay: (tx: Partial<Transaction>) => void }) {
  const { register, handleSubmit, formState: { errors } } = useForm<BankForm>({ resolver: zodResolver(bankSchema) });

  const onSubmit = (data: BankForm) => {
    onPay({
      toName: data.holderName,
      toUpiId: `ACC-${data.accountNumber.slice(-4)}`,
      amount: data.amount,
      method: 'bank',
      note: data.note,
    });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div>
        <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Account Holder Name</label>
        <input className="input" placeholder="As per bank records" {...register('holderName')} />
        {errors.holderName && <p style={{ color: '#ef4444', fontSize: 11, marginTop: 4 }}>{errors.holderName.message}</p>}
      </div>
      <div>
        <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Account Number</label>
        <input className="input" placeholder="Enter account number" {...register('accountNumber')} />
        {errors.accountNumber && <p style={{ color: '#ef4444', fontSize: 11, marginTop: 4 }}>{errors.accountNumber.message}</p>}
      </div>
      <div>
        <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>IFSC Code</label>
        <input className="input" placeholder="e.g. HDFC0001234" {...register('ifsc')} style={{ textTransform: 'uppercase' }} />
        {errors.ifsc && <p style={{ color: '#ef4444', fontSize: 11, marginTop: 4 }}>{errors.ifsc.message}</p>}
      </div>
      <AmountField register={register} error={errors.amount?.message} />
      <div>
        <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Note (Optional)</label>
        <input className="input" placeholder="Transfer purpose" {...register('note')} />
      </div>
      <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: 8 }}>
        <Building2 size={18} /> Initiate Transfer
      </button>
    </form>
  );
}

/* ─── Shared Amount Field ─────────────────────────────── */
function AmountField({ register, error }: { register: any; error?: string }) {
  const QUICK = [100, 500, 1000, 5000];
  return (
    <div>
      <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Amount (₹)</label>
      <div style={{ position: 'relative' }}>
        <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', fontSize: 16, fontWeight: 600 }}>₹</span>
        <input className="input" type="number" placeholder="0" {...register('amount')} style={{ paddingLeft: 32 }} />
      </div>
      {error && <p style={{ color: '#ef4444', fontSize: 11, marginTop: 4 }}>{error}</p>}
    </div>
  );
}

/* ─── Pay Confirm Card ────────────────────────────────── */
function PayConfirmCard({ name, upiId, amount, setAmount, trustScore, onPay, onBack }: {
  name: string; upiId: string; amount: string; setAmount: (v: string) => void;
  trustScore?: number; onPay: () => void; onBack: () => void;
}) {
  const tColor = trustScore !== undefined ? getTrustColor(trustScore) : '#10b981';
  const isValid = parseFloat(amount) > 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <button onClick={onBack} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', fontFamily: 'var(--font-main)', fontSize: 14 }}>
        <ArrowLeft size={16} /> Back
      </button>

      {/* Recipient card */}
      <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: 20, border: '1px solid var(--border-subtle)', display: 'flex', gap: 14, alignItems: 'center' }}>
        <div style={{ width: 52, height: 52, borderRadius: 16, background: getAvatarColor(name) + '20', display: 'flex', alignItems: 'center', justifyContent: 'center', color: getAvatarColor(name), fontWeight: 700, fontSize: 18, flexShrink: 0 }}>
          {getInitials(name)}
        </div>
        <div style={{ flex: 1 }}>
          <p style={{ fontWeight: 700, fontSize: 16 }}>{name}</p>
          <p style={{ color: 'var(--text-muted)', fontSize: 12 }}>{upiId}</p>
          {trustScore !== undefined && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
              <Shield size={10} color={tColor} />
              <span style={{ color: tColor, fontSize: 11, fontWeight: 600 }}>Trust {trustScore}%</span>
            </div>
          )}
        </div>
      </div>

      {/* Amount */}
      <div>
        <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginBottom: 6 }}>Amount (₹)</label>
        <div style={{ position: 'relative' }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', fontSize: 16, fontWeight: 600 }}>₹</span>
          <input
            className="input"
            type="number"
            placeholder="0"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            style={{ paddingLeft: 32, fontSize: 22, fontWeight: 700, height: 60 }}
          />
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
          {[100, 500, 1000, 5000].map((q) => (
            <button key={q} onClick={() => setAmount(String(q))}
              style={{ flex: 1, background: 'var(--bg-elevated)', border: '1px solid var(--border-subtle)', borderRadius: 10, padding: '6px 0', color: 'var(--text-secondary)', fontSize: 12, cursor: 'pointer', fontFamily: 'var(--font-main)' }}>
              ₹{q >= 1000 ? `${q/1000}K` : q}
            </button>
          ))}
        </div>
      </div>

      <button
        className="btn btn-primary"
        style={{ width: '100%', marginTop: 4 }}
        disabled={!isValid}
        onClick={onPay}
      >
        <Banknote size={18} />
        Pay {isValid ? formatINR(parseFloat(amount)) : 'Now'}
      </button>
    </div>
  );
}

/* ─── Fraud Alert Overlay ─────────────────────────────── */
function FraudAlertOverlay({ reasons, amount, toName, onProceed, onCancel }: {
  reasons: string[]; amount: number; toName: string; onProceed: () => void; onCancel: () => void;
}) {
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 28, padding: 28, width: '100%', maxWidth: 380 }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, marginBottom: 24 }}>
          <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'rgba(239,68,68,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', animation: 'pulse-ring 2s infinite' }}>
            <AlertTriangle size={32} color="#ef4444" />
          </div>
          <div style={{ textAlign: 'center' }}>
            <h2 style={{ color: '#ef4444', fontSize: 20, fontWeight: 800, marginBottom: 4 }}>⚠️ Fraud Alert</h2>
            <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>
              Suspicious activity detected for <strong>{formatINR(amount)}</strong> to <strong>{toName}</strong>
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 24 }}>
          {reasons.map((r, i) => (
            <div key={i} style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 12, padding: '10px 14px', display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <span style={{ color: '#ef4444', fontSize: 16 }}>•</span>
              <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{r}</p>
            </div>
          ))}
        </div>

        <p style={{ color: 'rgba(239,68,68,0.7)', fontSize: 12, textAlign: 'center', marginBottom: 20 }}>
          Proceeding will reduce your Trust Score by 20% and flag this transaction.
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <button onClick={onCancel} className="btn btn-primary" style={{ width: '100%' }}>
            <Shield size={16} /> Cancel – Keep me Safe
          </button>
          <button onClick={onProceed} style={{ background: 'none', border: '1px solid rgba(239,68,68,0.3)', color: 'rgba(239,68,68,0.7)', borderRadius: 14, padding: '12px', cursor: 'pointer', fontSize: 13, fontFamily: 'var(--font-main)' }}>
            Proceed Anyway (at my risk)
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Processing Screen ───────────────────────────────── */
function ProcessingScreen({ amount, toName, countdown, paused, onPause, onResume, onCancel }: {
  amount: number; toName: string; countdown: number; paused: boolean;
  onPause: () => void; onResume: () => void; onCancel: () => void;
}) {
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: 'var(--bg-card)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: 28, padding: 32, width: '100%', maxWidth: 380, textAlign: 'center' }}>
        {/* Animated ring */}
        <div style={{ position: 'relative', width: 120, height: 120, margin: '0 auto 24px' }}>
          <svg width={120} height={120} style={{ transform: 'rotate(-90deg)' }}>
            <circle cx={60} cy={60} r={50} fill="none" stroke="rgba(99,102,241,0.15)" strokeWidth={6} />
            <circle
              cx={60} cy={60} r={50} fill="none"
              stroke="#6366f1"
              strokeWidth={6}
              strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 50}
              strokeDashoffset={2 * Math.PI * 50 * (countdown / 8)}
              style={{ transition: 'stroke-dashoffset 1s linear' }}
            />
          </svg>
          <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ fontSize: 28, fontWeight: 800, color: 'var(--text-primary)' }}>{countdown}s</span>
          </div>
        </div>

        <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>Verifying with bank…</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginBottom: 4 }}>
          Sending <strong style={{ color: 'var(--text-primary)' }}>{formatINR(amount)}</strong>
        </p>
        <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 28 }}>to {toName}</p>

        {paused && (
          <div style={{ background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.25)', borderRadius: 12, padding: '10px 16px', marginBottom: 20 }}>
            <p style={{ color: '#f59e0b', fontSize: 13, fontWeight: 600 }}>⏸ Transaction Paused</p>
            <p style={{ color: 'rgba(245,158,11,0.7)', fontSize: 11, marginTop: 2 }}>Review details before continuing</p>
          </div>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {!paused ? (
            <button onClick={onPause} style={{ background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.3)', color: '#f59e0b', borderRadius: 14, padding: '14px', cursor: 'pointer', fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-main)' }}>
              ⏸ PAUSE &amp; RECHECK
            </button>
          ) : (
            <button onClick={onResume} className="btn btn-primary" style={{ width: '100%' }}>
              ▶ Resume Payment
            </button>
          )}
          <button onClick={onCancel} style={{ background: 'none', border: '1px solid rgba(239,68,68,0.3)', color: '#ef4444', borderRadius: 14, padding: '12px', cursor: 'pointer', fontSize: 13, fontFamily: 'var(--font-main)' }}>
            Cancel Payment
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Result Screen ───────────────────────────────────── */
function ResultScreen({ status, tx, onDone }: { status: 'success' | 'failed'; tx: Partial<Transaction> | null; onDone: () => void }) {
  const isSuccess = status === 'success';
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20 }}>
        <div
          style={{
            width: 100, height: 100, borderRadius: '50%',
            background: isSuccess ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: isSuccess ? '0 0 40px rgba(16,185,129,0.2)' : '0 0 40px rgba(239,68,68,0.2)',
            animation: 'pulse-ring 2s ease-out',
          }}
        >
          {isSuccess ? <CheckCircle size={50} color="#10b981" /> : <XCircle size={50} color="#ef4444" />}
        </div>
        <div>
          <h2 style={{ fontSize: 24, fontWeight: 800, marginBottom: 6 }}>
            {isSuccess ? 'Payment Successful!' : 'Payment Cancelled'}
          </h2>
          {isSuccess && tx?.amount && (
            <p style={{ fontSize: 32, fontWeight: 800, color: '#10b981' }}>{formatINR(tx.amount)}</p>
          )}
          {isSuccess && tx?.toName && (
            <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginTop: 4 }}>
              Sent to {tx.toName}
            </p>
          )}
        </div>
        <button className="btn btn-primary" onClick={onDone} style={{ marginTop: 8 }}>
          Back to Dashboard
        </button>
      </div>
    </div>
  );
}
